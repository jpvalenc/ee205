#include <stdio.h>
#include "BankAccount.h"

struct BankAccount {
    double balance;
    double last_withdrawl;
    double last_deposit;
};

BankAccount* BankAccount_construct(double balance) {
    struct BankAccount *account = malloc(sizeof(BankAccount)); // initialize account pointer and allocate memory

    // initialize balance and other struct variables
    account->balance = balance;
    account->last_deposit = 0;
    account->last_withdrawl = 0;

    // return the pointer to the bank account
    return account;
};

void BankAccount_destroy(BankAccount* ba) {
    free(ba); // free the memory allocated on exit
};

int BankAccount_deposit(BankAccount* ba, double amount) {
    ba->balance = ba->balance + amount; // add to balance
    ba->last_deposit = amount; // save this deposit for history

    return 0; // success
};

int BankAccount_withdraw(BankAccount* ba, double amount) {
    ba->balance = ba->balance - amount; // remove from balance
    ba->last_withdrawl = amount; // save this withdrawal for historyy

    return 0; // success
};

double BankAccount_get_balance(BankAccount* ba) {
    return ba->balance; // return balance
};

double BankAccount_get_last_deposit(BankAccount* ba) {
    return ba->last_deposit; // return last_deposit
};

double BankAccount_get_last_withdrawal(BankAccount* ba) {
    return ba->last_withdrawl; // return last_withdrawal
};

/*
 * Implement the definitions for the
 * functions involving BankAccount from BankAccount.h here,
 *
 * Make sure to produce comments that look like this!
 * (Try to copy the formatting.)
 *
 * For BankAccount_construct() and BankAccount_destroy(),
 * if you do not remember malloc() and free(), review them
 * by creating a toy program.
 */

