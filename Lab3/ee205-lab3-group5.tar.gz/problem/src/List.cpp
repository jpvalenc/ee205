#include "List.hpp"

#include <utility>

List::List() {
  // Initialize list
  this->head = nullptr;
  this->length = 0;
}

// Performs a deep copy, copying each node of the other list
// into this one
List::List(const List& other) {
  // Store other head in temp pointer
  ListNode *otherTemp = other.head;

  // Store head into a temp pointer
  ListNode *thisTemp = this->head;

  // Create new head
  this->head = new ListNode(otherTemp->data);

  int i; // counter

  // loop through temp pointer 
  while (thisTemp != nullptr) {
    // Create new pointer to other listnode data
    thisTemp->set_next(new ListNode(otherTemp->data));
    // Go to the next other and this temp to continue process
    otherTemp = otherTemp->get_next();
    thisTemp = thisTemp->get_next();
  }

  // Copy length
  this->length = other.length;
};

// Performs a move, moving the internal list from the other
// vector to this one, and invalidates the other list pointer
// for its memory
List::List(List&& other) {
  // completely move head and length
  this->head = std::move(other.head);
  this->length = std::move(other.length);

  ListNode *otherTemp = other.head;
  ListNode *nodeToDelete;

  // delete other list
  while (otherTemp != nullptr) {
    // Store other temp
    nodeToDelete = otherTemp;

    // Get next other temp
    otherTemp = otherTemp->get_next();
    
    // Delete the stored temp pointer
    delete nodeToDelete;
  }
  
  // Deinitialize other list
  other.head = nullptr;
  other.length = 0;
};

// Deallocates the memory in this list.
List::~List() {
  // Get pointer to head
  ListNode *temp = this->head;

  // Loop through temp
  while (temp != nullptr) {
    // Store temp in temporary variable
    ListNode *nodeToDelete = temp;

    // Get next
    temp->get_next();

    // Delete temp variable
    delete nodeToDelete;
  }

  delete this->head;
};

// For all of the following functions,
// throw a const char* (string) if the index is out of
// the bounds of the list.

// Appends a ListNode onto the end of the list
//
// Throw a const char* if the index is out of bounds
void List::append(int num) {
  int i; // counter variable

  ListNode *temp = this->head; // store head in temp pointer
  ListNode newList(num); // create new listnode with number provided

  // loop until we get to the end
  while (temp != nullptr) {
    temp->get_next();
  }

  // then set the ending node to the newly created listnode
  temp->set_next(newList.get_next());
};

// Inserts a ListNode before the index
//
// Throw a const char* if the index is out of bounds.
// Appending at the end is valid (e.g. insert(list.size(), 0)
// is valid)
void List::insert(int index, int num) {
  // change pointer of node before and
  // set the pointer of the node at the index to the next one

  if (index < 0 || index > length + 1) {
    throw "Out of bounds";
  }

  int i; // counter

  // If list index is at 0
  if (index == 0) {
    // Create pointer to new listnode
    ListNode *newNode = new ListNode(num);

    // set new listnode's pointer to the current head
    newNode->set_next(this->head);

    // Set new head to the new node
    this->head = newNode;
  // If index is at length
  } else if (index == length) {
    // Append to list
    append(num);
  } else {
    // store head into temp pointer
    ListNode *temp = this->head;
    // Temp pointer to store node before index
    ListNode *nodeBeforeIndex;
    // New node to be inserted
    ListNode *newNode = new ListNode(num);

    // Loop through list until node before index
    for (i = 0; i < index - 1; i++) {
      temp = temp->get_next();
    }

    // store node before index
    nodeBeforeIndex = temp;

    // go to next node
    temp = temp->get_next();

    // set the node pointer to the node before the index
    nodeBeforeIndex->set_next(newNode);

    // set the new node to a pointer to the next node
    newNode->set_next(temp->get_next());

    // increase length
    length = length + 1;
  }
};

// Removes the ListNode at the index
//
// Throw a const char* if the index is out of bounds.
void List::remove(int index) {
  // loop until index
  // set index to null pointer
  // save the pointer before the index
  // loop through list after index, 

  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }

  int i; // counter

  // If delete at index 0
  if (index == 0) {
    // Store head into temp pointer
    ListNode *temp = this->head;

    // get next node and set it to head to replace it
    this->head = temp->get_next();

    // delete temp pointer
    delete temp;
    
  } else if (index > 0) {
    // store temp head
    ListNode *temp = this->head;
    // store node before index
    ListNode *nodeBeforeIndex;

    for (i = 0; i < index; i++) {
      // Get next pointer
      temp = temp->get_next();

      // If the node before index, store it 
      if (i == index - 1) {
        nodeBeforeIndex = temp;
      }
    }

    // Set node before index to the node after the deleted node index
    nodeBeforeIndex->set_next(temp->get_next());

    // Delete temp pointer
    delete temp;
  }

  // Decrement length
  length = length - 1;
};

// Returns the int at the index
//
// Throw a const char* if the index is out of bounds.
int List::get(int index) const {
  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }

  int i; // counter

  // Store head into temp variable
  ListNode *temp = this->head;

  // Loop until index of get
  for (i = 0; i < index; i++) {
    temp = temp->get_next();
  }

  // Return data of temp pointer  
  return temp->get_data();
};

// Returns the length of the list
std::size_t List::size() const {
  return this->length;
};

// Reutrns a readable/writeable reference to the element at index
//
// Throw a const char* if the index is out of bounds.
int& List::operator[](int index) {
  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }

  int i; // counter

  // store head into temp variable
  ListNode *temp = head;

  for (i = 0; i < index; i++) {
    temp = temp->get_next();
  }

  // Return data of temp pointer
  return temp->data;
};