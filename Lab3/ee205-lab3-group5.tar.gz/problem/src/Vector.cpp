#include "Vector.hpp"

#include <utility>

void Vector::double_capacity() {
  // Make new array multiply capacity by 2
  int *double_capacity = new int[capacity * 2];

  int i; // counter var

  // Reassign old array to new temp one with doubled capacity
  for (i = 0; i < length; i++) {
    double_capacity[i] = arr[i];
  }

  // Assign temp array to official array
  arr = double_capacity;

  // Delete temp array
  delete double_capacity;
};

Vector::Vector() {
  // Initialize values
  length = 0;
  arr = new int[1];
  capacity = 0;
};

Vector::Vector(const Vector& other) {
  // Copy over values
  length = other.length;
  capacity = other.capacity;
  
  // Create temp array
  int *a = new int[other.capacity];

  int i; // counter

  // Copy other array to temp array
  for (i = 0; i < other.length; i++) {
    a[i] = other.arr[i];
  }

  // Set internal array to temp array
  arr = a;

  delete a; // Delete temp array
};

Vector::Vector(Vector&& other) {
  // Copy over values
  length = other.length;
  capacity = other.capacity;

  // Temp array
  int *a = new int[other.length];

  int i; // counter

  // Loop through the other array and copy to temp array
  for (i = 0; i < other.length; i++) {
    a[i] = other.arr[i];
  }

  // Copy temp array to class variable
  arr = a;

  delete a; // delete temp array
  
  // Delete other vector values
  other.length = 0;
  other.arr = nullptr;
  other.capacity = 0;
};

Vector::~Vector() {
  // Remove array from memory
  delete arr;
};

void Vector::append(int num) {
  // check the length and capacity, if length < capacity then append
  // if length >= capacity then call double_capacity function
  if (length >= capacity) {
    double_capacity();
  }

  // Add the value by accessing the arr[length]
  arr[length] = num;

  // update length add by 1
  length = length + 1;
};

void Vector::insert(int index, int num) {
  // check the length and capacity, if length < capacity then append
  // if length >= capacity, call double_capacity function
  // Create temporary array, loop through the

  if (index < 0 || index > length + 1) {
    throw "Out of bounds";
  }

  if (length >= capacity) {
    double_capacity();
  }
  
  // Temp array
  int *a = new int[capacity];

  int i; // counter

  // If insert is at index 0
  if (index == 0) {
    // Check if beginning of array
    for (i = length; i >= 0; i--) {
      // If loop is at 0, set the value
      if (i == 0) {
        a[0] = num;
      // Otherwise shift everything up
      } else {
        a[i] = arr[i - 1];
      }
    }
  // If insert is at index length, append to array
  } else if (index == length) {
    append(num);
  } else {
    for (i = length; i >= 0; i--) {
      // If less than index, set the same values
      if (i < index) {
        a[i] = arr[i];
      // If greater than index, shift values up
      } else if (i > index) {
        a[i] = arr[i - 1];
      // If at index, set value
      } else if (i == index) {
        a[index] = num;
      }
    }
  }

  // Increase length by 1
  length = length + 1;

  // Assign temp array as new official array
  arr = a;

  // Delete unused temp array
  delete a;
};

void Vector::remove(int index) {
  // Get the index and delete it.
  // Shift down all by 1
  // If less than 0 or greather than length - 1 throw err
  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }
  
  // Create pointer to a temporary array
  int *a = new int[capacity];

  // Counter var
  int i;

  // Loop through 
  for (i = 0; i < length; i++) {
    // If less than index, keep value the same in temp array
    if (i < index) {
      a[i] = arr[i];
    // If greather than index, shift down values by 1
    } else if (i > index) {
      a[i - 1] = arr[i];
    }
  }

  // Reduce length by 1
  length = length - 1;

  // Assign temp array as new official array
  arr = a;

  // Delete unused temp array
  delete a;
};

int Vector::get(int index) const {
  // If less than 0 or greather than length - 1 throw err
  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }

  // Return array at index by immutable value
  return arr[index];
};

// Return length of vector
std::size_t Vector::size() const {
  return length;
};

int& Vector::operator[](int index) {
  // If less than 0 or greather than length - 1 throw err
  if (index < 0 || index > length - 1) {
    throw "Out of bounds";
  }

  // Return array at index by reference
  return arr[index];
};
